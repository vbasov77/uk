
<?php $__env->startSection('content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <?php
    ?>
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex bg-dark"
             style="background-size: cover;background-position: center; background-image: url(<?php echo e(url("img/bg_image/$front[3]")); ?>);">
        <div class="container-fluid">
            <div class="row  justify-content-center align-items-center d-flex text-center h-100">
                <div class="col-12 col-md-8  h-50 ">
                    <div class="block_bg">
                        <h1 style="color: <?php echo e($front[1]); ?>; font-family: <?php echo e($front[2]); ?>;"
                            class="display-2  mb-2 mt-5 fro">
                            <strong><?php echo e($front[0]); ?></strong></h1>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('search.room')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row gx-0 mb-5 mb-lg-0 justify-content-center">
                                <div class="col-9">
                                    <label for="date_book" style="color: white; width: 90%"><b>Выберете
                                            дату:</b></label>
                                    <div class="front">
                                        <input id="input-id" name="date_book" type="text"
                                               class="form-control text-center" style="display:inline"
                                               value="<?php echo e(session('date_book') ?? ''); ?>"
                                               placeholder="Нажмите для выбора даты" autocomplete="off"
                                               readonly="readonly"
                                               required>
                                    </div>
                                    <br>
                                    <div>
                                        <center>
                                            <input class="form-control col-5 text-center" name="people"
                                                   placeholder="Количество гостей" type="text"
                                                   value="<?php echo e(session('people') ?? ''); ?>"
                                                   onkeypress="return (event.charCode >= 48 && event.charCode <= 57 && /^\d{0,3}$/.test(this.value));">
                                        </center>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <input class="btn btn-danger" type="submit" style="color: white" value="Продолжить">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section style="margin-top: 40px" class="section text-center">
        <div class="container-fluid px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem;">
                        <?php if($value->path != null): ?>
                            <img src="<?php echo e(asset("images/$value->path")); ?>" class="card-img-top"
                                 alt="...">
                        <?php else: ?>
                            <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>" class="card-img-top" alt="...">
                        <?php endif; ?>
                        <div class="card-body">
                            <div style="float: left; opacity: .6; ">
                                <?php for($i = 0; $i < $value ['capacity']; $i++): ?>
                                    <i class="fa fa-user"></i>
                                    
                                <?php endfor; ?>
                                <?php if(!empty($value ['price'] )): ?>
                                    &nbsp;<b>От:<?= $value ['price']  ?></b><i class="fa fa-rub"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-outline-success"
                                    onclick="window.location.href = '<?php echo e(route('num.id', ['id'=>$value ['id']])); ?>';">Подробнее
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <script src="<?php echo e(asset('js/calendars/calendar.js')); ?>" defer></script>
    </section>
    <section>
        <div style="margin-top: 25px; margin-bottom: 25px; text-align: center;">
            <h2>На карте</h2>
        </div>
        <div id="map" style="width: 100%; height: 400px"></div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
        <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/hotel-datepicker.min.js')); ?>" defer></script>

        <script>
            var start = <?php echo json_encode($start, 15, 512) ?>;
            var min = <?php echo json_encode((int)$rules[1], 15, 512) ?>;
            var max = <?php echo json_encode((int)$rules[2], 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/calendars/calendar.js')); ?>" defer></script>


        <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
        <script>
            // Функция ymaps.ready() будет вызвана, когда
            // загрузятся все компоненты API, а также когда будет готово DOM-дерево.
            ymaps.ready(init);

            function init() {
                // Создание карты.
                // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/map-docpage/
                var myMap = new ymaps.Map("map", {
                    // Координаты центра карты.
                    // Порядок по умолчнию: «широта, долгота».
                    center: [59.9386, 30.3141],
                    // Уровень масштабирования. Допустимые значения:
                    // от 0 (весь мир) до 19.
                    zoom: 8,
                    // Элементы управления
                    // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/controls/standard-docpage/
                    controls: [

                        'zoomControl', // Ползунок масштаба
                        'rulerControl', // Линейка
                        'routeButtonControl', // Панель маршрутизации
                        'trafficControl', // Пробки
                        'typeSelector', // Переключатель слоев карты
                        'fullscreenControl', // Полноэкранный режим

                        // Поисковая строка
                        new ymaps.control.SearchControl({
                            options: {
                                // вид - поисковая строка
                                size: 'large',
                                // Включим возможность искать не только топонимы, но и организации.
                                provider: 'yandex#search'
                            }
                        })

                    ]
                });

                // Добавление метки
                // https://tech.yandex.ru/maps/doc/jsapi/2.1/ref/reference/Placemark-docpage/
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                var myPlacemark = new ymaps.Placemark([<?php echo e($obj['coordinates']); ?>], {
                        // Хинт показывается при наведении мышкой на иконку метки.
                        hintContent: 'Содержимое всплывающей подсказки',
                        // Балун откроется при клике по метке.
                        balloonContent: '<center><div><?php echo e($obj->address); ?><br>от <?php echo e($obj->price); ?> <i style="opacity: .8;" class="fa fa-rub"></i><br><a href="<?php echo e(route('num.id',['id' => $obj-> id])); ?>" class="btn btn-outline-success btn-sm"> Перейти</a> </div></center>'
                    });

                // После того как метка была создана, добавляем её на карту.
                myMap.geoObjects.add(myPlacemark);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/front.blade.php ENDPATH**/ ?>