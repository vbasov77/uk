
<?php $__env->startSection('content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <section class="projects-section bg-light" id="projects">
        <div class="container px-4 px-lg-5">
            <div class="row justify-content-center text-center">
                <div style="padding: 20px">
                    <h3><?php echo e($data ['name_room']); ?></h3><br>
                </div>

                <div class="col-xl-8">
                    <div id="carusel" class="carousel slide" data-ride="carousel">
                        <ul class="carousel-indicators">
                            <?php if(!empty($photo)): ?>
                                <?php for($s = 0; $s < count($photo); $s++): ?>
                                    <?php
                                        if ($s == 0){
                                             $active = "active";
                                        } else {$active = "";}
                                    ?>
                                    <li data-target="#carusel" data-slide-to="<?php echo e($s); ?>" class="<?php echo e($active); ?>"></li>
                                <?php endfor; ?>
                            <?php endif; ?>
                        </ul>
                        <div class="carousel-inner">

                            <?php if(!empty($photo)): ?>
                                <?php for($i = 0; $i < count($photo); $i++): ?>
                                    <?php
                                        if ($i == 0){
                                            $carusel = "carousel-item active";
                                             } else {$carusel = "carousel-item";}
                                    ?>
                                    <div class="<?php echo e($carusel); ?>">
                                        <img src="<?php echo e(asset('images/' . $photo[$i])); ?>" alt="">
                                    </div>

                                <?php endfor; ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/no_image/no_image.jpg')); ?>" alt="">
                            <?php endif; ?>
                            <a class="carousel-control-prev" href="#carusel" data-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </a>
                            <a class="carousel-control-next" href="#carusel" data-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </a>
                        </div>
                    </div>

                </div>

                <div class="col-xl-4">
                    <?php if(!empty($data['price'])): ?>
                        <div style="font-size: 30px; margin-bottom: 15px; opacity: .7; margin-top: 45px; ">
                            <b> От <?php echo e($data ['price']); ?> <i class="fa fa-rub"></i></b>
                        </div>
                    <?php endif; ?>
                    <?php if(!empty($data['service'])  ): ?>
                        <h3 style="padding: 15px">Сервис</h3>
                        <?php
                            $service = explode(',', $data['service']);
                        ?>

                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="font-size: 23px;">
                                <i class="fa fa-check"></i> <?php echo e($value); ?><br>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                </div>
            </div>
            <br>
            <div class="row justify-content-center text-center">
                <div class="col-lg-6">
                    <h3 style="padding: 15px">Забронировать</h3>
                    <form action="<?php echo e(route('add.calendar')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
                        <label for="date_book"><b>Выберете дату:</b></label>
                        <div>
                            <input id="input-id" style="margin-bottom: 15px; text-align: center "
                                   name="date_book"
                                   type="text"
                                   class="form-control" value="<?php echo e(session('date_book') ?? ''); ?>"
                                   placeholder="Нажмите для выбора даты" autocomplete="off"
                                   readonly
                                   required>
                        </div>
                        <div>
                            <label for="guests"><b>Количество гостей:</b></label><br>
                            <?php for($i = 0; $i < $data->capacity; $i++): ?>
                                <div>
                                    <input required class="radio" type="radio" name="guests" value="<?php echo e($i + 1); ?>"
                                            <?php
                                                if (!empty(session('people')) and session('people') == $i + 1) {
                                                    echo 'checked';
                                                }
                                            ?>
                                    >
                                    <?php echo e($i + 1); ?> чел. <br>
                                </div>
                            <?php endfor; ?>
                        </div>
                        <div>
                            <input class="btn btn-outline-success" type="submit" value="Забронировать">
                        </div>
                    </form>
                </div>
                <div class="col-lg-6">
                    <h3 style="padding: 15px">Подробнее</h3>

                    <div style="font-size: 18px">
                        <?php echo $data->text_room; ?>

                    </div>
                </div>
            </div>

            <br>
            <br>
            <div class="row justify-content-center text-center">
                <div class="col-12">
                    <?php if(!empty($video)): ?>
                        <div>
                            <iframe width="560" height="315" src="<?php echo e($video); ?>" title="YouTube video player"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen></iframe>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <br>
        </div>
    </section>
    <section>
        <div style="margin-top: 25px; margin-bottom: 25px; text-align: center;">
            <h2>На карте</h2>
        </div>
        <div id="map" style="width: 100%; height: 400px"></div>
    </section>
    <section>
        <div class="row justify-content-center text-center">
            <?php if(auth()->guard()->guest()): ?>
            <?php else: ?>
                <?php if(Auth::user()->isAdmin()): ?>
                    <div>
                        <button class="btn btn-success btn-sm" style="color: white; margin-top: 25px"
                                onclick="window.location.href = '<?php echo e(route('edit.room', ['id'=>$data->id])); ?>'">
                            Редактировать номер
                        </button>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
        <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/hotel-datepicker.min.js')); ?>" defer></script>
        <script>
            var datebook = <?php echo json_encode($date_book, 15, 512) ?>;
            var start = <?php echo json_encode($start, 15, 512) ?>;
            var min = <?php echo json_encode((int)$rules[1], 15, 512) ?>;
            var max = <?php echo json_encode((int)$rules[2], 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/calendars/calendar2.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/get/get_cost.js')); ?>" defer></script>


        <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
        <script>
            // Функция ymaps.ready() будет вызвана, когда
            // загрузятся все компоненты API, а также когда будет готово DOM-дерево.
            ymaps.ready(init);

            function init() {
                // Создание карты.
                // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/map-docpage/
                var myMap = new ymaps.Map("map", {
                    // Координаты центра карты.
                    // Порядок по умолчнию: «широта, долгота».
                    center: [59.9386, 30.3141],
                    // Уровень масштабирования. Допустимые значения:
                    // от 0 (весь мир) до 19.
                    zoom: 9,
                    // Элементы управления
                    // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/controls/standard-docpage/
                    controls: [

                        'zoomControl', // Ползунок масштаба
                        'rulerControl', // Линейка
                        'routeButtonControl', // Панель маршрутизации
                        'trafficControl', // Пробки
                        'typeSelector', // Переключатель слоев карты
                        'fullscreenControl', // Полноэкранный режим
                        // Поисковая строка
                        new ymaps.control.SearchControl({
                            options: {
                                // вид - поисковая строка
                                size: 'large',
                                // Включим возможность искать не только топонимы, но и организации.
                                provider: 'yandex#search'
                            }
                        })
                    ]
                });

                // Добавление метки
                // https://tech.yandex.ru/maps/doc/jsapi/2.1/ref/reference/Placemark-docpage/


                var myPlacemark = new ymaps.Placemark([<?php echo e($data-> coordinates); ?>], {
                    // Хинт показывается при наведении мышкой на иконку метки.
                    hintContent: 'Содержимое всплывающей подсказки',
                    // Балун откроется при клике по метке.
                    balloonContent: '<center><div><?php echo e($data-> address); ?><br><?php echo e($data-> price); ?><br></div></center>'
                });

                // После того как метка была создана, добавляем её на карту.
                myMap.geoObjects.add(myPlacemark);

            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/rooms/view.blade.php ENDPATH**/ ?>