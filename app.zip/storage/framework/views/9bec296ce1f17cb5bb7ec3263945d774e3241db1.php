
<?php $__env->startSection('content'); ?>
    <?php
        $_monthsList = [
    "1"=>"Январь","2"=>"Февраль","3"=>"Март",
    "4"=>"Апрель","5"=>"Май", "6"=>"Июнь",
    "7"=>"Июль","8"=>"Август","9"=>"Сентябрь",
    "10"=>"Октябрь","11"=>"Ноябрь","12"=>"Декабрь"];
    $month = $_monthsList[date("n")];
    $last_month = $_monthsList[date("n",strtotime("-1 Months"))];
    ?>

    <section class="section">
        <div class="container-fluid px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">

                <h1 style="margin-top: 40px">Отчёт за <?php echo e($month); ?></h1>
                <?php
                    $total = 0;
$all_night = 0;
$all_sum = 0;
$all_to_issue = 0;
                ?>
                <table style="text-align: left" class="table">
                    <thead>
                    <tr>
                        <th scope="col">Адрес</th>
                        <th scope="col">Ночей</th>
                        <th scope="col">Приход</th>
                        <th scope="col">Расход</th>
                        <th scope="col">Итог</th>
                        <th scope="col"><?php echo e($last_month); ?></th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $report = \App\Models\Report::where('room_id', $room-> id)->where('month', date('m.Y'))->first();
                            $last_report = \App\Models\Report::where('room_id', $room-> id)->where('month', date('m.Y',strtotime("-1 Months")))->first();
                            $to_issue = $report['sum'] * (65 / 100);
$zp = $report['sum'] * (35 / 100)

                        ?>
                        <tr>

                            <th scope="row"> <?php echo e($room-> address); ?> </th>
                            <th scope="row"> <?php echo e($report['count_night']); ?> </th>
                            <th scope="row"> <?php echo e($report['sum']); ?> </th>
                            <th scope="row"> <?php echo e($to_issue); ?> </th>
                            <th scope="row"> <?php echo e($zp); ?> </th>
                            <?php if($last_report['paid'] == null): ?>
                                <th scope="row"><small>Не существует</small></th>
                            <?php elseif($last_report['paid'] == 2): ?>
                                <th style="color: green" scope="row"> Выплачен</th>
                            <?php else: ?>
                                <th style="color: red" scope="row"> Не выплачен</th>
                            <?php endif; ?>
                            <td>
                                <button class="btn btn-success btn-sm" style="color: white; margin-top: 25px"
                                        onclick="window.location.href = '<?php echo e(route('my.obj', ['id' => $room->id])); ?>';">
                                    Подробнее
                                </button>
                            </td>
                        </tr>
                        <?php

                            $all_night = $all_night + $report['count_night'];
                            $all_sum = $all_sum + $report['sum'];
                            $all_to_issue = $all_to_issue + $to_issue;
                            $total = $total + $zp;

                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <br>
                </table>
                <h4>ИТОГО:</h4>
                <br>
                <table style="text-align: left" class="table">
                    <thead>
                    <tr>
                        <th scope="col">Ночей</th>
                        <th scope="col">Приход</th>
                        <th scope="col">Расход</th>
                        <th scope="col">Итог</th>

                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <th scope="row"> <?php echo e($all_night); ?> </th>
                        <th scope="row"> <?php echo e($all_sum); ?> </th>
                        <th scope="row"> <?php echo e($all_to_issue); ?> </th>
                        <th scope="row"> <?php echo e($total); ?> </th>
                        <td>
                            <button class="btn btn-success btn-sm" style="color: white; margin-top: 25px"
                                    onclick='window.location.href = "#";'>
                                Подробнее
                            </button>
                        </td>
                    </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/reports/view.blade.php ENDPATH**/ ?>