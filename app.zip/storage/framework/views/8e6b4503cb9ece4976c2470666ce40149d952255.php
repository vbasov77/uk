<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <br>
                    <h3>Создать номер</h3><br>
                    <form
                            id="form" action="<?php echo e(route('room')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="name_room"><b>Номер (название):</b></label>
                            <input name="name_room" type="text" value="<?php echo e(old('name_room')); ?>"
                                   class="form-control"
                                   placeholder="№ 13" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="address"><b>Адрес:</b></label>
                            <input name="address" type="text" value="<?php echo e(old('address')); ?>"
                                   class="form-control"
                                   placeholder="Боровая 11" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="price"><b>Цена:</b></label>
                            <input name="price" type="text" value="<?php echo e(old('price')); ?>"
                                   class="form-control"
                                   placeholder="1500" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="text_room"><b>Текст:</b></label>
                            <textarea placeholder="Введите текст" name="text_room" cols="85" rows="5"
                                      value="<?php echo e(old('text_room')); ?>" class="form-control"></textarea>
                        </div>
                        <br>
                        <div>
                            <label for="capacity"><b>Вместимость(человек):</b></label>
                            <input name="capacity" type="text" value="<?php echo e(old('capacity')); ?>"
                                   class="form-control"
                                   placeholder="3" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="service"><b>Сервис:</b></label>
                            <input name="service" type="text" value="<?php echo e(old('service')); ?>"
                                   class="form-control"
                                   placeholder="фен, утюг, телевизор, холодильник..." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="video"><b>Видео YouTube:</b></label>
                            <input name="video" type="text" value="<?php echo e(old('video')); ?>"
                                   class="form-control"
                                   placeholder="https://www.youtube.com/watch?v=WviGn7gjhdw" autocomplete="off"
                                   required>
                        </div>
                        <br>
                        <div>
                            <label for="coordinates"><b>Координаты:</b></label>
                            <input name="coordinates" type="text" value="<?php echo e(old('coordinates')); ?>"
                                   class="form-control"
                                   placeholder="" autocomplete="off">
                        </div>
                        <br>
                        <div>
                            <label for="user_id"><b>Присвоить юзеру ID:</b></label>
                            <input name="user_id" type="number" value="<?php echo e(old('user_id')); ?>"
                                   class="form-control"
                                   placeholder="1" autocomplete="off" required>
                        </div>
                        <br>
                        <button class="btn btn-primary submit" id="submit" type="submit">Перейти дальше</button>
                    </form>

                </div>
            </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
            <script src="<?php echo e(asset('dropzone/drop.js')); ?>" defer></script>
        <?php $__env->stopPush(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/rooms/view_add.blade.php ENDPATH**/ ?>