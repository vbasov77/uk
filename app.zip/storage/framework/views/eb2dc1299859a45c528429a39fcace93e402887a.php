<?php $__env->startSection('content'); ?>


    <center><h1 style="margin-top: 25px">Все объекты</h1><br></center>
    <section class="section text-center">
        <div class="container-fluid px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <?php if(!empty(count($rooms))): ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Фото</th>
                            <th scope="col">Название</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"> <?php echo e($room->id); ?> </th>
                                <td>
                                    <?php if($room->path != null): ?>
                                        <img src="<?php echo e(asset("images/$room->path")); ?>" style="width: 80px; height: auto"
                                             alt="...">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>"
                                             style="width: 80px; height: auto" alt="...">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($room->title); ?></td>
                                <td>
                                    <button class="btn btn-success btn-sm" style="color: white; margin-top: 25px"
                                            onclick="window.location.href = '<?php echo e(route('schedule.add', ['id'=>$room->id])); ?>';">
                                        Добавить
                                    </button>
                                    <button class="btn btn-info btn-sm" style="color: white; margin-top: 25px"
                                            onclick="window.location.href = '<?php echo e(route('schedule.edit', ['id'=>$room->id])); ?>';">
                                        Изменить
                                    </button>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    Не найдено...
                <?php endif; ?>
            </div>
        </div>


        <div id="calendar"></div>

    </section>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/schedule/view.blade.php ENDPATH**/ ?>