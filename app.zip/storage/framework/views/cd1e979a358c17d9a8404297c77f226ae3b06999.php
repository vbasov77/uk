<?php $__env->startSection('content'); ?>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h2><?php echo e($name_room); ?></h2>
                    <form action="<?php echo e(route('schedule.edit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="room" value="<?php echo e($id); ?>">
                        <h3> Изменить расписание </h3>
                        <br>
                        <h3> Выбор дат </h3><br>
                        <div class="size">
                            <label for="date_book"><b>Выберете даты, которые нужно изменить:</b></label>
                            <input  id="input-id" name="date_book" type="text" class="form-control"
                                   placeholder="Нажмите для выбора даты" autocomplete="off" required>
                        </div>

                        <br>
                        <div>
                            <input class="btn btn-outline-primary" type="submit" value="Изменить">
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <?php $__env->startPush('scripts'); ?>
            <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
            <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
            <script src="<?php echo e(asset('js/hotel-datepicker.min.js')); ?>" defer></script>

            <script src="<?php echo e(asset('js/calendars/schedule_cal2.js')); ?>" defer></script>
        <?php $__env->stopPush(); ?>

    </section>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/schedule/edit.blade.php ENDPATH**/ ?>