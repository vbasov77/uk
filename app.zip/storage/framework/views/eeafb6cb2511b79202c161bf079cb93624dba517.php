<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center text-center">
                <div class="col-lg-8">
                    <h3 style="margin-top: 25px">Бронь</h3>
                    <br>
                    <?php if(!empty($data)): ?>
                        <?php for($i = 0; $i < count($data); $i++): ?>
                            <?php
                                $pay = explode(';', $data [$i]->info_pay);
                                $phone = preg_replace("/[^0-9]/", '', $data [$i]->phone_user);
                                $archive  =
                                    \App\Models\Archive::where('email_user', $data [$i]->email_user)
                                        ->orWhere('phone_user', $data [$i]->phone_user)
                                        ->get(['otz', 'id']);
                            ?>

                            <div class="card text-center" style="margin: 15px">
                                <div class="card-header">
                                    Даты: <?php echo e($data [$i]->no_in); ?>- <?php echo e($data [$i]->no_out); ?><br>
                                </div>
                                <div class="card-body">
                                    Имя: <?php echo e($data[$i]->name_user); ?><br>
                                    Телефон: <a href='tel:+<?php echo e($phone); ?>'><?php echo e($data [$i]->phone_user); ?></a><br>
                                    Сумма: <?php echo e($data [$i]->summ); ?><br>
                                    <?php if($pay[0] == 0): ?>
                                        Не оплачен
                                    <?php else: ?>
                                        Оплачен
                                    <?php endif; ?>
                                    <?php if(!empty(count($archive))): ?>
                                        <br><small><i>Имеются отзывы:
                                                <?php echo e($num = 1); ?>

                                                <?php $__currentLoopData = $archive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div style="color: red">
                                                        <?php echo e($num++ . ". " . $value ['otz']); ?>

                                                        <button class="btn btn-outline-link btn-sm"
                                                                style="margin: 5px"
                                                                onclick="window.location.href = '<?php echo e(route('view.archive', ['id'=>$data[$i]->id])); ?>';">
                                                            <small>Подробнее</small>
                                                        </button>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </i></small>
                                    <?php endif; ?>

                                </div>
                                <div class="card-footer text-muted">
                                    <?php if($data [$i]->confirmed == 0): ?><br>
                                    <button class="btn btn-outline-success btn-sm"
                                            style="margin: 5px"
                                            onclick="window.location.href = '<?php echo e(route('order.confirm', ['id'=> $data[$i]->id])); ?>';">
                                        Подтвердить
                                    </button>
                                    <button class="btn btn-outline-secondary btn-sm"
                                            style="margin: 5px"
                                            onclick="window.location.href = '<?php echo e(route('order.reject', ['id'=> $data[$i]->id])); ?>';">
                                        Отклонить
                                    </button>
                                    <br>
                                    <?php endif; ?>
                                    <button class="btn btn-outline-warning btn-sm"
                                            style="margin: 5px"
                                            onclick="window.location.href = '<?php echo e(route('order.verification', ['id'=> $data[$i]->id])); ?>';">
                                        Подробнее
                                    </button>
                                    <a onClick="return confirm('Подтвердите удаление!')"
                                       href='<?php echo e(route('order.delete', ['id'=> $data[$i]->id])); ?>' type='button'
                                       class='btn btn-outline-danger btn-sm' style="margin: 5px">Удалить</a>
                                    <br>
                                    <br>
                                    <form action="<?php echo e(route('in.archive')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($data[$i]-> id); ?>"/>
                                        <i>Отзыв администратора</i><br>
                                        <input type="text" name="otz" id="otz" class="form-control"
                                               placeholder="Отзыв администратора"/>
                                        <br>
                                        <div>
                                            <input id="submit" class="btn btn-outline-dark btn-sm" type="submit"
                                                   value="В архив"/>

                                        </div>
                                    </form>

                                </div>

                            </div>
                        <?php endfor; ?>
                    <?php else: ?>
                        Заказов не найдено((
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/otz/otz.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/orders/orders.blade.php ENDPATH**/ ?>