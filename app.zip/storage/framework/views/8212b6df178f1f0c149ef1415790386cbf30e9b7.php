<?php $__env->startSection('content'); ?>



    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h2><?php echo e($name_room); ?></h2>
                    <form action="<?php echo e(route('schedule.add')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="room" value="<?php echo e($id); ?>">
                        <h3> Создать расписание </h3>
                        <br>
                        <h3> Выбор дат </h3><br>
                        <div>
                            <label for="date_book"><b>Выберете даты:</b></label>
                            <input id="input-id" name="date_book" type="text" class="form-control"
                                   placeholder="Нажмите для выбора даты" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="cost"><b>Минимальная стоимость:</b></label>
                            <input name="cost" type="text" class="form-control"
                                   placeholder="Минимальная цена" required>
                        </div>
                        <br>
                        <div>
                            <input class="btn btn-outline-primary" type="submit" value="Создать">
                        </div>
                    </form>
                    <button class="btn btn-outline-success btn-sm"
                            onclick="window.location.href = '<?php echo e(route('schedule')); ?>';">
                        Назад
                    </button>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
        <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/hotel-datepicker.min.js')); ?>" defer></script>
        <script>
            var datebook = <?php echo json_encode($date_book, 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/calendars/schedule_cal.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/schedule/schedule.blade.php ENDPATH**/ ?>