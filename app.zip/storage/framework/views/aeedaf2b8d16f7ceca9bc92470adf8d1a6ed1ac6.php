<?php $__env->startSection('content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <section class="about-section text-center" id="about">
        <div class="container-fluid px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card" style="width: 18rem;">
                        <?php if($value->path != null): ?>
                            <img src="<?php echo e(asset("images/$value->path")); ?>" class="card-img-top"
                                 alt="...">
                        <?php else: ?>
                            <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>" class="card-img-top" alt="...">
                        <?php endif; ?>
                        <div class="card-body">
                            <div style="float: left; opacity: .6; ">
                                <?php for($i = 0; $i < $value ['capacity']; $i++): ?>
                                    <i class="fa fa-user"></i>
                                <?php endfor; ?>
                                <?php if(!empty($value->price )): ?>
                                    &nbsp;<b>От:<?php echo e($value->price); ?></b><i class="fa fa-rub"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-outline-success"
                                    onclick="window.location.href = '<?php echo e(route('num.id', ['id'=>$value->id])); ?>';">Подробнее
                            </button>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views//search/search_room.blade.php ENDPATH**/ ?>