<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">

                    <h3>Редактировать главную страницу</h3>

                    <form action="<?php echo e(route('front.edit')); ?>" onsubmit="return Validate(this);"
                          enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <label><b>Заголовок</b></label><br>
                        <div>
                            <input class="form-control" value="<?php echo e($data[0] ?? ''); ?>" type="text"
                                   name="data[]"
                                   method="post" required><br>
                        </div>

                        <div>
                            <label><b>Цвет заголовка</b></label><br>
                            <input class="form-control" value="<?php echo e($data[1] ?? ''); ?>" type="text"
                                   name="data[]"
                                   method="post" required><br>
                        </div>
                        <div>
                            <label><b>Шлифт заголовка</b></label><br>
                            <input class="form-control" value="<?php echo e($data[2] ?? ''); ?>" type="text"
                                   name="data[]"
                                   method="post" required><br>
                        </div>

                        <div>
                            <label><b>Фото фона</b></label><br>
                            <input class="form-control" value="<?php echo e($data[3] ?? ''); ?>" type="text"
                                   name="data[]" readonly="readonly"
                                   method="post" required><br>
                        </div>

                        <div>
                            <label><b>Изменить фото фона</b></label><br>
                            <input class="form-control" type="file"
                                   name="file"
                                   method="post"><br>
                        </div>
                        
                        
                        
                        
                        
                        
                        <div>
                            <input class="btn btn-outline-success" type="submit" value="Сохранить">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
            <script src="<?php echo e(asset('js/checks/check_file.js')); ?>" defer></script>
        <?php $__env->stopPush(); ?>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/settings/front_settings.blade.php ENDPATH**/ ?>