<?php $__env->startSection('content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h1 style="margin-top: 40px">Весь период</h1>
                    <?php if(!empty(count($reports))): ?>
                        <table style="text-align: left" class="table">
                            <thead>
                            <tr>
                                <th scope="col">Месяц</th>
                                <th scope="col">Ночей</th>
                                <th scope="col">Выплачено</th>
                                <th scope="col">Статус</th>


                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if($report->paid == 1){
                                      $paid = "<div style='color: green;'>Выплачен</div>";
                                    } else{
        $paid = "<div style='color: red;'>Не выплачен</div>";
                                    }
                                ?>
                                <tr>
                                    <th scope="row"> <?php echo e($report->month); ?> </th>
                                    <th scope="row"> <?php echo e($report->count_night); ?> </th>
                                    <th scope="row"> <?php echo e($report->sum); ?> </th>
                                    <th scope="row"> <?php echo $paid; ?> </th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        Отчётов пока не найдено...
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/reports/room_reports.blade.php ENDPATH**/ ?>