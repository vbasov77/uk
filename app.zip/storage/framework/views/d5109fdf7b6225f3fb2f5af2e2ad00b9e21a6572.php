
<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h3>Заполните форму</h3>
                    <form action="<?php echo e(route('order.info')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
                        <input type="hidden" name="sum" value=" <?php echo e($sum); ?>">
                        <input type="hidden" value="<?php echo e(implode(",", $date_view)); ?>" name="date_view">
                        <input type="hidden"
                               value="Итого: <b><?php echo e($sum_night); ?></b> сут./<b><?php echo e($sum); ?> руб.</b>"
                               name="summ">
                        <div class="border_none">
                            <label for="date_book"><b>Выбранные даты:</b></label><br>
                            <input class="form-control" value="<?php echo e($data['date_book']); ?>"
                                   readonly="readonly" type="text"
                                   name="date_book"
                                   method="post"><br>
                        </div>
                        <br>
                        <div style="background: #e9ecef; padding: 15px;">
                            <?php $__currentLoopData = $date_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($dat); ?> руб.<br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            Итого: <b><?php echo e($sum_night); ?></b> сут./<b><?php echo e($sum); ?>руб.</b>
                        </div>
                        <br>

                        <div>
                            <label for="phone_user"><b>Телефон:</b></label><br>
                            <input name="phone_user" type="text" class="tel form-control"
                                   value="<?php echo e(old('phone_user')); ?>" placeholder="+7(000) 000-0000" required>
                        </div>
                        <br>
                        <div>
                            <label for="email_user"><b>Email:</b></label>
                            <input name="email_user" type="email" class="form-control"
                                   onKeypress="javascript:if(event.keyCode == 32)event.returnValue = false;"
                                   value="<?php echo e(old('email_user')); ?>" placeholder="Email" required>
                        </div>
                        <br>
                        <?php for($i = 1; $i <= $data['guests']; $i++): ?>
                            <h3> <?php echo e($i); ?> гость</h3>
                            <div>
                                <label for="ФИО"><b>ФИО:</b></label>
                                <input name="name_user[]" id="name_user" type="text" class="form-control"
                                       value="<?php echo e(old('name_user')); ?>" placeholder="ФИО" required>
                            </div>
                            <div>
                                <label for="age"><b>Возраст:</b></label>
                                <input name="age[]" type="text" class="form-control"
                                       value="<?php echo e(old('age')); ?>" placeholder="Полных лет" required>
                            </div>
                            <div>
                                <label for="from"><b>Район:</b></label>
                                <input name="from[]" type="text" class="form-control"
                                       placeholder="Город, область жительства" required>
                            </div>
                            <br>
                        <?php endfor; ?>
                        <br>
                        <div>
                            <input class="btn btn-outline-primary" type="submit" value="Продолжить">
                        </div>
                        <br>
                        <br>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/masks/mask.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/email/email.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/orders/order_info.blade.php ENDPATH**/ ?>