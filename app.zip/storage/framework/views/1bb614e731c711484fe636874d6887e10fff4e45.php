<?php $__env->startSection('content'); ?>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <form action="<?php echo e(route('edit.table')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Дата</th>
                            <th scope="col">Цена</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"> <?php echo e($data['id']); ?></th>
                                <td><?= $data['date_book'] ?></td>
                                <td>
                                    <input type="text" name="cost[]"
                                           value="<?php echo e((int)$data->cost); ?>">
                                    <input type="hidden" name="id[]" value="<?php echo e($data->id); ?>">
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div>
                        <input class="btn btn-outline-primary" type="submit" value="Изменить">
                    </div>
                </form>
            </div>
        </div>


    </section>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/schedule/edit_table.blade.php ENDPATH**/ ?>