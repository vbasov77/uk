
Здравствуйте, <?php echo e($data ['name_user']); ?>!<br>
<br>
Вы забронировали номер по адресу:<br>

<br>
<br>
Дата и время въезда: <?php echo e($data ['in']); ?>с 14.00<br>
Дата и время выезда: <?php echo e($data ['out']); ?> до 12.00<br>
<br>
Итого: <?php echo e($_POST ['sum']); ?> руб<br>
<br>
Ожидайте подтверждения бронироания...<br>

С уважением,<br>
администрация сайта <?php echo e(config('app.name')); ?>!
<?php /**PATH C:\OpenServer\domains\uk\resources\views/mail/send_book.blade.php ENDPATH**/ ?>