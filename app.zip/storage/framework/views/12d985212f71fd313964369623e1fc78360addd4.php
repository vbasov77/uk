<?php $__env->startSection('content'); ?>

    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style>
        .picker input#input-id {
            display: none;
        }

        .picker .datepicker__info.datepicker__info--feedback.datepicker__info--help {
            display: none;
        }

        .picker button#clear-input-id {
            display: none;
        }

        .picker .datepicker__topbar {
            display: none;
        }

        .picker div#datepicker-input-id {
            right: 0;
            left: 0;
            margin: auto;
        }

        div#datepicker-input-id {
            position: inherit;
        }
    </style>
    <?php
        $_monthsList = [
"1"=>"Январь","2"=>"Февраль","3"=>"Март",
"4"=>"Апрель","5"=>"Май", "6"=>"Июнь",
"7"=>"Июль","8"=>"Август","9"=>"Сентябрь",
"10"=>"Октябрь","11"=>"Ноябрь","12"=>"Декабрь"];
$month = $_monthsList[date("n")];
$last_month = $_monthsList[date("n",strtotime("-1 Months"))];
$last_sum = 0;
$status = "";
$confirm = "";

if (!empty($last_report)){
    $last_sum = $last_report['sum'];
    if($last_report->paid == 2){
        $status = "<div style='color: green;'>Выплачен</div>";
    } elseif ($last_report->paid == 1){
$status = "<div style='color: red;'>Не выплачен</div>";
$confirm = "<button class='btn btn-outline-danger btn-sm'
                                                style='margin: 5px'
                                                onclick='window.location.href = '{{route('paid.confirm', ['id'=>$last_report->room_id, 'month' => $last_report->month])}}';'>
                                            Выплатить
                                        </button>";
    }
}

    ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <div style="margin-top: 50px">
                        <h1>Отчёт</h1>
                        <h3><?php echo e($data->address); ?></h3>

                    </div>

                    <div class="card text-center" style="margin: 15px">
                        <div class="card-header">
                            Выплата за - <?php echo e($last_month); ?>: <?php echo e($last_sum); ?> <i style="opacity: .8;"
                                                                           class="fa fa-rub"></i><small><?php echo $status; ?></small>

                        </div>
                    </div>

                    <?php if(Auth::user()->isAdmin()): ?>
                        <h4>Админ инфо</h4>
                        <?php if(!empty($last_report)): ?>
                            <?php
                                $paid = $last_report['sum'] * (65 / 100);
                            ?>
                            <div class="card text-center" style="margin: 15px">
                                <div class="card-header">
                                    <h5>Выплаты за прошлый месяц <?php echo e($last_month); ?></h5>
                                </div>
                                <div class="card-body">
                                    Всего ночей <b> <?php echo e($last_report['count_night']); ?></b><br>
                                    К выплате: <?php echo e($paid); ?> <i style="opacity: .8;" class="fa fa-rub"></i>
                                </div>
                                <div class="card-footer text-muted">
                                    <?php if($last_report['paid'] == 1): ?>
                                        <button class="btn btn-outline-danger btn-sm"
                                                style="margin: 5px"
                                                onclick="window.location.href = '<?php echo e(route('paid', ['id'=>$last_report->room_id, 'month' => $last_report->month, 'paid'=>$paid])); ?>';">
                                            Выплатить
                                        </button>
                                    <?php else: ?>
                                        <div style="color: #2fa360">
                                            <b><h5>Выплачено</h5></b>
                                        </div>
                                        <button class="btn btn-outline-danger btn-sm"
                                                style="margin: 5px"
                                                onclick="window.location.href = '<?php echo e(route('paid.cancel', ['id'=>$last_report['room_id'], 'month' => $last_report['month'], 'paid'=>$paid])); ?>';">
                                            Отменить
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <button class="btn btn-primary btn-sm"
                                        style="margin: 5px"
                                        onclick="window.location.href = '<?php echo e(route('reports')); ?>';">
                                    Назад
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="card text-center" style="margin: 15px">
                                <div class="card-header">
                                    Данных для администратора не найдено
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div>
                        <h3><?php echo e($month); ?></h3>
                        Занятых ночей <b><?php echo e($month); ?> - <?php echo e($count_night); ?> </b><br>
                        Сумма <b><?php echo e($month); ?> - <?php echo e($sum); ?> <i style="opacity: .8;" class="fa fa-rub"></i></b><br>
                    </div>

                    <button class="btn btn-outline-success btn-sm"
                            onclick="window.location.href = '<?php echo e(route('room.reports', ['id'=> $data['id']])); ?>';">Весь
                        период
                    </button>

                    <section>
                        <div class="container picker">
                            <div style="margin-top: 40px">
                                <center>
                                    <input id="input-id" name="date_book" type="text"
                                           class="form-control text-center"
                                           value="<?php echo e(session('date_book') ?? ''); ?>" readonly="readonly"
                                           required>
                                </center>
                            </div>

                        </div>
                    </section>
                </div>
            </div>

        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
        <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/hotel-datepicker.min.js')); ?>" defer></script>
        <script>
            var datebook = <?php echo json_encode($date_book, 15, 512) ?>;
            var start = <?php echo json_encode($start, 15, 512) ?>;
            var min = <?php echo json_encode((int)$rules[1], 15, 512) ?>;
            var max = <?php echo json_encode((int)$rules[2], 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/calendars/calendar3.js')); ?>" defer></script>

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/reports/reports_obj.blade.php ENDPATH**/ ?>