
<?php $__env->startSection('content'); ?>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center text-center">
            <div class="col-lg-8">
                <form action="<?php echo e(route('add.booking')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>">
                    <input type="hidden" name="sum" value="<?php echo e($sum); ?>">
                    <input type="hidden" value="<?php echo e(implode(",", $date_view)); ?>" name="date_view">
                    <h3>Проверьте данные:</h3><br>
                    <div class="border_none">
                        <label for="date_book"><b>Выбранные даты:</b></label><br>

                        <input class="form-control" value="<?php echo e($_POST['date_book']); ?>" readonly="readonly" type="text"
                               name="date_book"
                               method="post"><br>
                    </div>
                    <?php $__currentLoopData = $date_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <?php echo $value; ?> <br>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <div class="border_none">
                        <label for="phone_user"><b>Телефон:</b></label><br>

                        <input class="form-control" value="<?php echo e($_POST['phone_user']); ?>" readonly="readonly" type="text"
                               name="phone_user"
                               method="post"><br>
                    </div>
                    <div class="border_none">
                        <label for="email_user"><b>Email:</b></label><br>
                        <input class="form-control" value="<?php echo e($_POST['email_user']); ?>" readonly="readonly" type="text"
                               name="email_user"
                               method="post"><br>
                    </div>
                    <b>Гости:</b>
                    <?php $__currentLoopData = $more_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border_none">
                        <input class="form-control" value="<?php echo e($item); ?>" readonly="readonly" type="text"
                               name="more_book[]"
                               method="post">
                        <br>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <div>
                        <input class="btn btn-outline-primary" type="submit" value="Подтвердить">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/verifications/verification_booking.blade.php ENDPATH**/ ?>