SPB-R.RU<br>
Новое бронирование<br>
<br>
Даты: <?php echo e($data['in'] . ' - ' . $data ['out']); ?><br>
<br>
Забронировал: <?php echo e($data['name_user']); ?><br>
<br>
Пройдите по ссылке <a href="<?php echo e(request()->root()); ?>/order/<?php echo e($data['id']); ?>/verification">Здесь</a>
<br>

С уважением,<br>
администрация сайта <?php echo e(config('app.name')); ?>!


<?php /**PATH C:\OpenServer\domains\uk\resources\views/mail/new_booking.blade.php ENDPATH**/ ?>