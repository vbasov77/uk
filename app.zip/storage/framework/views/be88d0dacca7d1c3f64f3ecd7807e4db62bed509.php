
<?php $__env->startSection('content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <div class="container">
        <center>
            <div style="font-size: 150px; opacity: .8; color: #2fa360">
                <i class="fa fa-frown-o" aria-hidden="true"></i>
            </div>
            <div style="margin-top: 40px">
            <h3>Извините, что-то пошло не так. <br>
                Скорее всего администратором не указана цена одной из дат. <br>
                Свяжитесь с администратором!</h3>
            </div>
        </center>
        <font color='#99b1c6'><i class="fas fa-cat fa-5x"></i></font>
        <br>
        <br>



    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\uk\resources\views/sorry/sorry.blade.php ENDPATH**/ ?>