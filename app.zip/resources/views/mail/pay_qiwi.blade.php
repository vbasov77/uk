
Оплата по номеру заказа {{$data ['bill'] ['comment']}} произведена. <br>
Сумма оплаты: {{$data ['bill'] ['amount']['value']}}


С уважением,<br>
администрация сайта {{config('app.name')}}!