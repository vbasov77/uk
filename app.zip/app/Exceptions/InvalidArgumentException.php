<?php


namespace App\Exceptions;


class InvalidArgumentException extends \Exception
{

}
